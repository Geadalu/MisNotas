// Este código ha sido incluido desde un 
// fichero externo (HolaMundo.c)
#include <stdio.h>
int main(int argc, char* argv[]) {
  puts("¡Hola mundo!");
}