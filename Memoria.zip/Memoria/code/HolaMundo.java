/* 
   El programa Hola Mundo muestra un saludo en la pantalla
*/
public class HolaMundo {
    public static void main(String[] args){
      //Muestra "Hola Mundo!"
      System.out.println("Hola Mundo!");     
    } 
}